package com.example.langify1;

public class DisplayLevel {

}
